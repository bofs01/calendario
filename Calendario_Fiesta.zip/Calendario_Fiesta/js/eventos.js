$(document).ready(function () {
    $('#calendar').evoCalendar({
        theme: 'Royal Navy',
        language: 'es',
        calendarEvents: [
            {
                id: 'evento1', // Event's ID (required)
                name: "Año nuevo", // Event name (required)
                date: "January/1/2022", // Event date (required)
                type: "holiday", // Event type (required)
                everyYear: true // Same event every year (optional)
            },
            
            {
                name: "Inicio de la feria",
                badge: "06/08 - 06/15", // Event badge (optional)
                date: ["July/08/2022", "July/15/2022"], // Date range
                description: "Vacation leave for 3 days.", // Event description (optional)
                type: "event",
                everyYear: true,
                color: "#63d867" // Event custom color (optional)
            }
        ]
    })
})